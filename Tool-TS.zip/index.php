


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FEBAT Subportfolios</title>
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css" type="text/css" />
    <link rel="stylesheet" href="css/jqx.base.css" type="text/css" />
    <link rel="stylesheet" href="css/jqx.forec.css" type="text/css" />
    <link rel="stylesheet" href="css/app-specific.css" type="text/css" />
    <script type="text/javascript" src="node_modules/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="libs/jqxcore.js"></script>
    <script type="text/javascript" src="libs/jqxdata.js"></script>
    <script type="text/javascript" src="libs/jqxbuttons.js"></script>
    <script type="text/javascript" src="libs/jqxscrollbar.js"></script>
    <script type="text/javascript" src="libs/jqxmenu.js"></script>
    <script type="text/javascript" src="libs/jqxgrid.js"></script>
    <script type="text/javascript" src="libs/jqxgrid.selection.js"></script>
    <script type="text/javascript" src="libs/jqxgrid.columnsresize.js"></script>
    <script type="text/javascript" src="libs/jqxgrid.edit.js"></script>
    <script type="text/javascript" src="libs/jqxlistbox.js"></script>
    <script type="text/javascript" src="libs/jqxdropdownlist.js"></script>
    <script type="text/javascript" src="libs/jqxdatetimeinput.js"></script>
    <script type="text/javascript" src="libs/globalization/globalize.js"></script>
    <script type="text/javascript" src="libs/jqxcalendar.js"></script>
    <script type="text/javascript" src="libs/jqxdatetimeinput.js"></script>
    <script type="text/javascript" src="libs/jqxtree.js"></script>
    <script type="text/javascript" src="libs/jqxgrid.columnsreorder.js"></script>
    <script type="text/javascript" src="app.js"></script>

</head>
<body>
<div id="main-header"></div>
<div id="sizing-container" class="container-full" >
<!--    <div id="flyout-app"></div>-->
<!--    <div id="generalSettings-app" class="row"></div>-->
<!--    <div class="row"><div id="subPortfoliosGrid" class="grid-base"></div></div>-->


</div>

</body>
</html>