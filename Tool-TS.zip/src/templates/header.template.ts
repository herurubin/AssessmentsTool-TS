var singleLineHeaderTemplate =`

<nav class="navbar green-header">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Assessments Tool</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="header-item active-header"><a href="#" id="home">Home</a></li>
      <li class="header-item" ><a href="#" id="create">Create Assessments</a></li>
      <li class="header-item"><a href="#" id="fill-out">Fill Out Assessments</a></li>
      <li class="header-item"><a href="#" id="dashboard">Dashboard</a></li>
    </ul>
  </div>
</nav>
`
